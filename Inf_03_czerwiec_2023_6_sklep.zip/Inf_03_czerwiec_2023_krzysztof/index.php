<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sklep dla uczniów</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <section class="baner">
        <h1>Dzisiejsze promocje naszego sklepu</h1>
    </section>
    <section class = "lewy">
        <h2>Taniej o 30%</h2>
        <?php
        $poleczenie = mysqli_connect('localhost', 'root', '', 'sklep');
        $zapytanie = "SELECT nazwa FROM `towary` where promocja = 1";
        $wynik = mysqli_query($poleczenie, $zapytanie);

        while($row = mysqli_fetch_row($wynik))
        {
            echo"
            <ol><li>$row[0]</li>
            </ol>";
        }
        
        ?>
    </section>    
    <section class = "srodkowy">
        <h3>Sprawdź cenę</h3>
        <form action="index.php" method="post">
            <select name="produkty" >
                <option value="Gumka do mazania">Gumka do mazania</option>
                <option value="Cienkopis">Cienkopis</option>
                <option value="Pisaki 60 szt.">Pisaki 60 szt.</option>
                <option value="Markery 4 szt.">Markery 4 szt.</option>
            </select>
            <input type="submit" value="SPRAWDŹ">
        </form>
        <div>
            <?php
                $produkty = $_POST['produkty'];
                $ask = "SELECT cena, (cena * 0.7) from towary where nazwa like '$produkty'";
                $wynik2 = mysqli_query($poleczenie, $ask);
                
                while($row2 = mysqli_fetch_row($wynik2))
                {
                    echo"
                    cena regularna: $row2[0]</br>
                    cena w promocji 30%: $row2[1]
                    ";
                }
                mysqli_close($poleczenie);
                ?>
        </div>      
    </section>
    <section class = "prawy">
        <h2>Kontakt</h2>
        <p><a href="mailto: bok@sklep.pl">e-mail: bok@sklep.pl</a></p>
        <img src="promocja.png" alt="promocja">
    </section>
    <section class = "stopka">
        <h4>Autor strony: Autor</h4>
    </section>
    
</body>
</html>