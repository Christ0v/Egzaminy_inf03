<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Panel administratora</title>
    <link rel="stylesheet" type="text/css" href="styl4.css">
</head>
<body>
    <section class ="baner">
        <h3>Portal społecznościowy - panel administratora</h3>
    </section>
    <section class = "lewy">
        <tabel>
        <h4>Użytkownicy</h4>
        <?php
        $conn = mysqli_connect('localhost','root','','dane4');
        $sql = "SELECT id,imie,nazwisko,(Year(CURRENT_DATE()) - rok_urodzenia) FROM `osoby` LIMIT 30;";
        $result = mysqli_query($conn,$sql);
        
        while($row = mysqli_fetch_row($result))
        {
            echo"<div>$row[0]. $row[1] $row[2], $row[3] lat<div>";
        }
        ?>
        </table>
        <a href="setting.html">Inne ustawienia</a>
    </section>
    <section class="prawy">
        <h4>Podaj id użytkownika</h4>
        <form action="users.php" method="post">
            <input type="number" name='wybierz'>
            <button type="submit">ZOBACZ</button>
        </form>
        <hr></hr>
        <?php
        if(isset($_POST['wybierz']))
        {
            
            $wybierz = $_POST['wybierz'];
            if($wybierz == Null)
                echo"Nie podano id!";
            else
            {    
            $query="SELECT osoby.id,osoby.imie,osoby.nazwisko,osoby.rok_urodzenia,osoby.zdjecie,osoby.opis,hobby.nazwa FROM osoby,hobby Where osoby.Hobby_id = hobby.id AND osoby.id = $wybierz;" ;
            #$zap = "SELECT id,imie,nazwisko,rok_urodzenia,zdjecie FROM `osoby` Where id = $wybierz;";
            $res = mysqli_query($conn,$query);
            while($row = mysqli_fetch_row($res))
            {   
                echo" <h2>$wybierz. $row[1] $row[2]</h2> <img src='$row[4]'alt ='$wybierz' >";
                echo"<p>Rok urodzenia:$row[3]</p>";
                echo"Opis:$row[5]";
                echo"<p>Hobby:$row[6]</p>";
            }
            }

        }
        mysqli_close($conn);

        ?>
    </section>
    <footer>
        <p>Stronę wykonał: Krzysztof</p>
    </footer>

</body>
</html>